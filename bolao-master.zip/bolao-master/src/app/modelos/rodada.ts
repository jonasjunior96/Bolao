import { Partida } from './partida';

export class Rodada{
    partidas:Partida[];
    constructor(partidas:Partida[]){
        this.partidas = partidas;
    }
    get Partidas():Partida[]{
        return this.partidas;
    }
}