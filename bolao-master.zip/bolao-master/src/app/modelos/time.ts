import { Jogador } from './jogador'

export class Time{
    nome:string;
    estado:string;
    estadio:string;
    escudo:string;
    elenco:Jogador[];
    sigla:string;
    constructor(
        nome:string,
        estado:string,
        escudo:string,
        estadio:string,
        sigla:string
    ){
        this.nome = nome;
        this.estado = estado;
        this.escudo = escudo;
        this.estadio = estadio;
        this.sigla = sigla;
    }
    get Nome():string{
        return this.nome;
    }
    get Escudo():string{
        return this.escudo;
    }
    get Sigla():string{
        return this.sigla;
    }
}