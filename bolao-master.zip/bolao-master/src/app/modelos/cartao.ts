import { Jogador } from './jogador';

export class Cartao{
    jogador:Jogador;
    minutos:number;
    tipo:string;
}