import { Jogador } from './jogador';

export class Gol{
    jogador:Jogador;
    assistente:Jogador;
    minutos:number;
    golContra:boolean;
}