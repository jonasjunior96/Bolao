export class Jogador{
    nome:string;
    posicao:string;
    idade:number;
    peso:number;
    numeroCamisa:number;
    altura:number;
}