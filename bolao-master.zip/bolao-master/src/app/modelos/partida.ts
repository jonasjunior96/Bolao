import { Time } from './time';
import { Jogador } from './jogador';
export class Partida{
mandante:Time;
visitante:Time;
data:Date;
local:string;
placarMandante:number;
placarVisitante:number;
titularesMandante:Jogador[];
titularesVisitante:Jogador[];
reservasMandante:Jogador[];
reservasVisitante:Jogador[];

constructor(
    mandante:Time,
    visitante:Time,
    data:Date
){
    this.mandante = mandante;
    this.visitante = visitante;
    this.local = mandante.estadio;
    this.placarMandante = 0;
    this.placarVisitante = 0;
    this.data = data;
}
get Mandante():Time{
    return this.mandante;
}
get Visitante():Time{
    return this.visitante;
}
get PlacarMandante():number{
    return this.placarMandante;
}
get PlacarVisitante():number{
    return this.placarVisitante;
}
get Local():string{
    return this.local;
}

set Mandante(mandante:Time){
    this.mandante = mandante;
}
set Visitante(visitante:Time){
    this.visitante = visitante;
}
set PlacarMandante(placarMandante:number){
    this.placarMandante = placarMandante;
}
set PlacarVisitante(placarVisitante:number){
    this.placarVisitante=placarVisitante;
}
set Local(local:string){
    this.local = local;
}
get Data():Date{
    return this.data;
}
set Data(data:Date){
    this.data = data;
}
}